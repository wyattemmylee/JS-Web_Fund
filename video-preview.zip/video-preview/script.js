console.log("page loaded...");

document.getElementById("video-big").muted = true;

function play_Video (element){
    element.play();
}
function pause_Video (element){
    element.pause();
}